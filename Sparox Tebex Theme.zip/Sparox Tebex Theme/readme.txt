Thank you for purchasing Sparox Tebex Theme! You've officially gained my endless love.

Quick installation guide:
#1 Create Theme
	1. Go to Webstore > Design > Themes and click Create Custom Theme. 
	2. Enter your theme name, in this case Sparox and copy/paste the CSS that's provided with the theme.

#2 Create Template
	1. Go To Webstore > Design > Templates and click Create Custom Template. 
	2. Enter the name of the template (Sparox) and select the base Flat template. 
	3. Click Create. 
	4. Start copy/pasting the HTML files to the corresponding template (Twig) files.

Also take a look at Tebex's documentation page which is always up-to-date: https://docs.tebex.io/store/configuring-your-webstore/custom-css-and-html

If you encounter any problems regarding your product. Please contact me through the following platforms.
Discord: Gilles#1616
MC-Market: https://www.mc-market.org/members/63198/

Sparox Tebex - v1.2.0